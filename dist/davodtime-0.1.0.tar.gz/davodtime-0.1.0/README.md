# DavodTime CLI

A command line application (designed with the help of ChatGPT) designed to produce timestamps in the format `MMddYYYY-HHmmss` across timezones.